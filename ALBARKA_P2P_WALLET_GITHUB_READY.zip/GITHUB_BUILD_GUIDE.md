# Build ALBARKA P2P WALLET APK from GitHub

1. Create a GitHub repository named `albarka-p2p-wallet`.
2. Upload all files in this project to the repository (including `.github/workflows/build-android.yml`).
3. Open **Actions** → **Build Android APK** → **Run workflow**.
4. Wait for the workflow to finish.
5. Open the completed workflow run and download the artifact named `albarka-p2p-wallet-apk`.
6. Extract the artifact to get `app-release.apk`.

This build is a UI/demo starter. Do not use it with real funds. Production wallet cryptography, secure key storage, transaction signing, testnet testing, audits, and store compliance must be completed before mainnet use.
